from django.apps import AppConfig


class JdcapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jdcApi'

# from django.db.models import Q
from rest_framework import serializers
from jdcApi.models import MstSect, Saint
from datetime import datetime


class CREATESaintSerializer(serializers.ModelSerializer):
    dob = serializers.DateTimeField(input_formats=['%B %d, %Y'])  # according to 12hr clock to send default time 12:00 AM
    dobTime = serializers.TimeField(input_formats=['%I:%M %p'], allow_null=True)
    dikshaDate = serializers.DateField(input_formats=['%B %d, %Y'])
    devlokDate = serializers.DateTimeField(input_formats=['%B %d, %Y'], required=False, allow_null=True)
    devlokTime = serializers.TimeField(input_formats=['%I:%M %p'], allow_null=True)

    class Meta:
        model = Saint
        fields = ['name', 'sectId', 'fatherName', 'motherName', 'birthPlace', 'dikshaPlace', 'guruName','dob', 'dobTime', 'dikshaDate', 'devlokDate', 'devlokTime', 'gender', 'description']

    # def validate(self, data):
    #     """ set blank values to None """
    #     optional_fields = ['devlokDate', 'description']
    #     #check optional_field name in given data
    #     for field_name in optional_fields:
    #         if field_name in data and isinstance(data[field_name], str) and data[field_name].strip() == "":
    #             data[field_name] = None  # Set the field to None for empty strings with only spaces
    #     return data

    def to_internal_value(self, data):
        # print(data)
        sect_id = data.get('sectId')
        if sect_id:
            try:
                MstSect.objects.get(id=sect_id)
            except MstSect.DoesNotExist:
                raise serializers.ValidationError({'sectId': ['Invalid Sect ID']})
            except ValueError:
                raise serializers.ValidationError({'sectId': [f"'sectId' excepted a number but got '{sect_id}."]})
        # print(self.validate(data))
        # print(data)
        return super().to_internal_value(data)

    def create(self, validated_data):
        validated_data['name'] = validated_data['name'].capitalize()
        validated_data['fatherName'] = validated_data['fatherName'].capitalize()
        validated_data['motherName'] = validated_data['motherName'].capitalize()
        validated_data['guruName'] = validated_data['guruName'].capitalize()
        validated_data['birthPlace'] = validated_data['birthPlace'].capitalize()

        # Create the user instance with modified data
        saint_obj = self.Meta.model.objects.create(**validated_data)

        #  add data in field createdBy
        user_id_by_token = self.context.get('user_id_by_token')
        saint_obj.createdBy = user_id_by_token
        saint_obj.save()

        return saint_obj


class UPDATESaintSerializer(serializers.ModelSerializer):
    dob = serializers.DateField(input_formats=['%B %d, %Y'])
    dikshaDate = serializers.DateField(input_formats=['%B %d, %Y'])
    devlokDate = serializers.DateField(input_formats=['%B %d, %Y'],  allow_null=True)
    dobTime = serializers.TimeField(input_formats=['%I:%M %p'], allow_null=True)
    devlokTime = serializers.TimeField(input_formats=['%I:%M %p'], allow_null=True)


    class Meta:
        model = Saint
        fields = ['name', 'sectId', 'fatherName', 'motherName', 'birthPlace', 'dikshaPlace', 'guruName','dob', 'dobTime', 'dikshaDate', 'devlokDate','devlokTime', 'gender', 'description', 'isVerified']

    def update(self, instance, validated_data):
        # Update the user instance with modified data
        try:
            validated_data['name'] = validated_data['name'].capitalize()
            validated_data['fatherName'] = validated_data['fatherName'].capitalize()
            validated_data['motherName'] = validated_data['motherName'].capitalize()
            validated_data['guruName'] = validated_data['guruName'].capitalize()
            validated_data['birthPlace'] = validated_data['birthPlace'].capitalize()
        except KeyError:
            pass

        user_id_by_token = self.context.get('user_id_by_token')
        validated_data['updatedBy'] = user_id_by_token
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance

    def to_internal_value(self, data):
        sect_id = data.get('sectId')
        print(sect_id)
        if sect_id:
            try:
                MstSect.objects.get(id=sect_id)
            except MstSect.DoesNotExist:
                raise serializers.ValidationError({'sectId': ['Invalid Sect ID']})
            except ValueError:
                raise serializers.ValidationError({'sectId': [f"'sectId' excepted a number but got '{sect_id}."]})

        return super().to_internal_value(data)

    def validate(self, data):
        # Check if at least one field is being updated
        updated_fields = {key: value for key, value in data.items() if key in self.Meta.fields}
        if len(updated_fields) == 0:
            raise serializers.ValidationError({'update_validation_error':"At least one field must be provided for the update."})
        return data


# for search Saint
class GETAllSaintSerializer(serializers.ModelSerializer):
    dikshaDate = serializers.SerializerMethodField()

    class Meta:
        model = Saint
        fields = ['id', 'name', 'birthPlace', 'dikshaPlace', 'dikshaDate']

    def get_dikshaDate(self, saint):
        return saint.dikshaDate.strftime("%B %d, %Y")


class GETAllSaintBySectIdSerializer(serializers.ModelSerializer):
    dikshaDate = serializers.SerializerMethodField()
    dob = serializers.SerializerMethodField()

    class Meta:
        model = Saint
        fields = ['id', 'name', 'dob', 'birthPlace', 'dikshaPlace', 'dikshaDate']

    def get_dikshaDate(self, instance):
        return instance.dikshaDate.strftime("%B %d, %Y")

    def get_dob(self, instance):
        return instance.dob.strftime("%B %d, %Y")


class GETAllSaintForAdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = Saint
        fields = ['id', 'name']


class GETSaintByIdSerializer(serializers.ModelSerializer):
    sect = serializers.CharField(source='sectId.sectName', read_only=True)
    dob = serializers.SerializerMethodField()
    devlokDate = serializers.SerializerMethodField()
    dikshaDate = serializers.SerializerMethodField()
    age = serializers.SerializerMethodField()
    dobTime = serializers.SerializerMethodField()
    devlokTime = serializers.SerializerMethodField()

    class Meta:
        model = Saint
        fields = ['id', 'name', 'sect','sectId', 'fatherName', 'motherName', 'birthPlace', 'dikshaPlace', 'guruName', 'age', 'dikshaDate','devlokDate', 'devlokTime', 'gender', 'dob', 'dobTime', 'dobTime', 'description']

    def get_age(self, instance):
        dob = instance.dob
        #  to find the age by using 'dob'
        birthdate = datetime.strptime(str(dob), '%Y-%m-%d')
        current_date = instance.devlokDate if instance.devlokDate else datetime.now()
        # Calculate the age
        age = current_date.year - birthdate.year - (
                (current_date.month, current_date.day) < (birthdate.month, birthdate.day))

        return age

    def get_dikshaDate(self, instance):
        return instance.dikshaDate.strftime("%B %d, %Y")

    def get_dob(self, instance):
        return instance.dob.strftime("%B %d, %Y")

    def get_dobTime(self, instance):
        dob_time = instance.dobTime
        return dob_time.strftime('%I:%M %p') if dob_time else ""

    def get_devlokDate(self, instance):
        dob_time = instance.devlokDate
        return dob_time.strftime("%B %d, %Y") if dob_time else ""
    def get_devlokTime(self, instance):
        devlok_time = instance.devlokTime

        return devlok_time.strftime('%I:%M %p') if devlok_time else ""


